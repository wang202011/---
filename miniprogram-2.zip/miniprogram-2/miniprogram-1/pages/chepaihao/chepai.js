// pages/chepaihao/chepai.
const app = getApp()
var util = require('../../utils/util.js')
const db = wx.cloud.database();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    numbe:[],
    
  },
  //文字调用识别接口
    shixian: function () {
      var that = this;
      var curDate = new Date();
      wx.request({
        url: util.TXAPI_BASE_URL + '/txapi/ocrimg/', //文字识别接口
        data: {
          key: util.TXAPI_KEY,
          // img:res.tempImagePath
        },
        success: function (res) {
          if (res.data.code == 200) {
            var newSource= res.data.newslist
            console.log(newSource)
            that.setData({
              // hideScroll: false,
              // bindSource: newSource,
              // arrayHeight: newSource.length * 
              // src:newSource         
            })
          } else {
            console.error('错误码：' + res.data.code + '\n错误提示：' + res.data.msg + '\n接口详情：https://www.tianapi.com/apiview/124')
            wx.showModal({
              title: '文字识别',
              content: res.data.msg,
              showCancel: false,
              success: function (res) {
                if (res.confirm) {
                  console.log('用户点击确定')
                }
              }
            })
            that.setData({
              hideScroll: true,
              // src: []
            })
          }
        }
      })
    },
//车牌识别调用接口
  Shibie(){
    wx.request({
      url: 'https://api.tianapi.com/ocrimg/index',
      method: 'POST', 
      data: {
	  key:' 密钥信息 ',img:' url',
	  },
      success: function (res) {
      wx.chooseImage({              //选取照片
        count: 1,
        sizeType: ['original', 'compressed'],
        sourseType: ['album', 'camera'],//本地或拍照选取
        success(res) {
          console.log(res)
         let url = res.tempFilePaths[0]		//获取图片地址
          //let url =' miniprogram-1\assets\img\车牌.jpg'
          wx.setStorageSync("res_imgurl", url);//缓存照片
          //图片转码为base64编码形式
          wx.getFileSystemManager().readFile({
            
            filePath: url,
            encoding: 'base64',
            success(res) {
              //console.log('上传照片成功准备转码')
              let base64 = res.data     //保存转码后数据

              //console.log('开始识别')
              wx.request({        //请求识花接口
                url: 'http://api.tianapi.com/ocrimg/index',
                header: {
                  "Content-type": "application/x-www-form-urlencoded",//决定用哪种post请求，是固定的
                },
                method: 'post',   //请求固定为post请求
                data: {           //请求时需要上传的数据
                  image: base64,	//图片编码数据
                  // access_token: token,//获取的token权限
                  baike_num: 1	//想得到的百度百科数量
                },
                success: function (res) {
                 // console.log('识别成功跳转页面')
                  console.log(res.data.result)//控制台输出识别后得到的数据中的结果
                }
              })
            }
          })
        }
      })
        if(res.data.code == 200){
       console.log(res.data)
         }
      },
      fail: function (err) {
        console.log(err)
      }
    })
  },
  error(e) {
    console.log(e.detail)
  },

// 摄像头拍照
  Creat(){
    var that = this;
      var curDate = new Date();
    // CameraContext.setZoom()
    const ctx = wx.createCameraContext()
    ctx.takePhoto({
      quality: 'high',
      success: (res) => {
        this.setData({
          src: res.tempImagePath,
        })
        // 获取拍照图片路径
        console.log(res.tempImagePath) 
        // 图片转base64提交给接口
        wx.getFileSystemManager().readFile({
          filePath: res.tempImagePath,
          encoding: "base64",
          success: function (image) {
            // console.log(image.data)//返回base64编码结果，但是图片的话没有data:image/png，但好像png是万能的
            // app.globalData.picturebase64=image.data
            // app.globalData.picturebase64 =app.globalData.picturebase64.replace(/[\r\n]/g, "")
            // console.log(app.globalData.picturebase64)
            wx.request({
              // url: util.TXAPI_BASE_URL + '/txapi/ocrimg/', //文字识别接口
              url: util.TXAPI_BASE_URL + '/txapi/licenseplate/', //车牌识别接口
              header: {
                  'content-type': 'application/x-www-form-urlencoded',
                },
                method:'POST',
              data: {
                key: util.TXAPI_KEY,
                // data: new Date(curDate.getTime() - 24 * 60 * 60 * 1000),
                img:image.data,
              },
              success: function (res) {
                if (res.data.code == 200) {
                  var newSource= res.data.newslist
                  console.log(newSource)
                  console.log(newSource[0])
                  // console.log(newSource[0].data)
                  // console.log(newSource[0].texts)
                 app.globalData.carnumber=(newSource[0].number)
                  // console.log(b)
                  // that.setData({
                    // hideScroll: false,
                    // bindSource: newSource,
                    // arrayHeight: newSource.length * 
                    // src:newSource
                    // a:newSource[0].data         
                  // })
                console.log( app.globalData.carnumber)
                } else {
                  console.error('错误码：' + res.data.code + '\n错误提示：' + res.data.msg + '\n接口详情：https://www.tianapi.com/apiview/124')
                  wx.showModal({
                    title: '车牌识别',
                    content: res.data.msg,
                    showCancel: false,
                    success: function (res) {
                      if (res.confirm) {
                        console.log('用户点击确定')
                      }
                    }
                  })
                  that.setData({
                    hideScroll: true,
                    // src: []
                  })
                }
              }
            })
          }
        })
      }
    })
  },

// 本地上传
  ChooseImg(){
    var that = this;
      var curDate = new Date();
wx.chooseImage({
  count:1,//只能选择一张照片
  sizeType: [ 'compressed'], // 可以指定是原图还是压缩图，这里压缩图
  sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
  success: function (res) {
    // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
    //选择好了之后开始读图片 success: (res) => {
        that.setData({
          srcx: res.tempFilePaths,
        })
    // }
    wx.getFileSystemManager().readFile({
      filePath: res.tempFilePaths[0],
      encoding: "base64",
      success: function (image) {
        // console.log(image.data)//返回base64编码结果，但是图片的话没有data:image/png，但好像png是万能的
        app.globalData.picturebase64=image.data
        app.globalData.picturebase64 =app.globalData.picturebase64.replace(/[\r\n]/g, "")
        console.log(app.globalData.picturebase64)
        wx.request({
          // url: util.TXAPI_BASE_URL + '/txapi/ocrimg/', //文字识别接口
          url: util.TXAPI_BASE_URL + '/txapi/licenseplate/', //车牌识别接口
          header: {
              'content-type': 'application/x-www-form-urlencoded',
            },
            method:'POST',
          data: {
            key: util.TXAPI_KEY,
            // data: new Date(curDate.getTime() - 24 * 60 * 60 * 1000),
            img:image.data,
          },
          success: function (res) {
            if (res.data.code == 200) {
              var newSource= res.data.newslist
              console.log(newSource)
              console.log(newSource[0])
              // console.log(newSource[0].data)
              // console.log(newSource[0].texts)
             app.globalData.carnumber=(newSource[0].number)
              // console.log(b)
              // that.setData({
                // hideScroll: false,
                // bindSource: newSource,
                // arrayHeight: newSource.length * 
                // src:newSource
                // a:newSource[0].data         
              // })
            console.log( app.globalData.carnumber)
            } else {
              console.error('错误码：' + res.data.code + '\n错误提示：' + res.data.msg + '\n接口详情：https://www.tianapi.com/apiview/124')
              wx.showModal({
                title: '垃圾分类',
                content: res.data.msg,
                showCancel: false,
                success: function (res) {
                  if (res.confirm) {
                    console.log('用户点击确定')
                  }
                }
              })
              that.setData({
                hideScroll: true,
                // src: []
              })
            }
          }
        })
      }
    })
  }
})

  },
  error(e) {
    console.log(e.detail)
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
   
  },
jianbie(){
    const db = wx.cloud.database();
    db.collection("chepaihao").where({
      num:String(app.globalData.carnumber)
    }).get({
      success: res => {
        // wx.showToast({
        //   title: '查询成功',
        //   icon:'success',
        //   duration: 2000,
        //    mask:true
        // })
    //     app.globalData.number.push(num)
          this.setData({
          numbe: res.data[0]//返回的是一个数组，取第一个    
        })
      },
      // fail:  
      // wx.showToast({
      //   title: '查询失败',
      //   icon:'error',
      //   duration: 1000,
      //   mask:true
      // })
    
      //  console.log("查询失败")
    
    })
  },
  
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
  
})