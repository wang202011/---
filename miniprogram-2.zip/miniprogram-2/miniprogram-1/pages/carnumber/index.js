
const app = getApp()
Page({
    
  /**
   * 页面的初始数据
   */
  data: {
    number:[],
    
    // 省份简写
    provinces: [
      ['京', '沪', '粤', '津', '冀', '晋', '蒙', '辽', '吉', '黑'],
      ['苏', '浙', '皖', '闽', '赣', '鲁', '豫', '鄂', '湘'],
      ['桂', '琼', '渝', '川', '贵', '云', '藏'],
      ['陕', '甘', '青', '宁', '新'],
    ],
    // 车牌输入
    numbers: [
      ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"],
      ["A", "B", "C", "D", "E", "F", "G", "H", "J", "K"],
      ["L", "M", "N", "P", "Q", "R", "S", "T", "U", "V"],
      ["W", "X", "Y", "Z", "港", "澳", "学"]
    ],
    carnum: [],
    showNewPower: false,
    KeyboardState: true
  },
  // 选中点击设置
  bindChoose(e) {
    if (!this.data.carnum[6] || this.data.showNewPower) {
      var arr = [];
      arr[0] = e.target.dataset.val;
      this.data.carnum = this.data.carnum.concat(arr)
      this.setData({
        carnum: this.data.carnum
      })
    }
  },
  ChooseImg(){
    // const ctx = wx.createCameraContext()
    wx.navigateTo({
      url: '/pages/chepaihao/chepai',
      // url: '/pages/hot/hot',
    })
  },
  bindDelChoose() {
    if (this.data.carnum.length != 0) {
      this.data.carnum.splice(this.data.carnum.length - 1, 1);
      this.setData({
        carnum: this.data.carnum
      })
    }
  },
  showPowerBtn() {
    this.setData({
      showNewPower: true,
      KeyboardState: true
    })
  },
  closeKeyboard() {
    this.setData({
      KeyboardState: false
    })
  },
  openKeyboard() {
    this.setData({
      KeyboardState: true
    })
  },
  // 提交车牌号码
  submitNumber() {
    //if (this.data.carnum[6]) {
      // 跳转到tabbar页面
    //}
    // const app = getApp()
    // list=this.data.carnum[6]
    // const DB = wx.cloud.database().collection("chepaihao")
    // console.log(this.data.carnum)
   
    let car=this.data.carnum[0]+this.data.carnum[1]+this.data.carnum[2]+this.data.carnum[3]+this.data.carnum[4]+this.data.carnum[5]+this.data.carnum[6]
    
    // const db = wx.cloud.database()//必须有
    // const _ = db.command//这个有时需要用到，比如数据的自增、自减时

    // const result =  db.collection('chepaihao').where({
    //  num:car
    // }).get()
    //  console.log(result)

  //  let a= wx.cloud.database().collection('chepaihao')
  //    .doc('1').get()
  //    console.log(a)
    
    // if (car=='赣HA1111') {
    //   // 跳转到tabbar页面
    //   console.log("正确")
    // }
    // else
    // console.log('错误')

    // const db = wx.cloud.database().collection("chepaihao")
    // const result=db.where({
    //   num:car
    // }) .get()
    
    //单个查询成功
    
    const db = wx.cloud.database();
   
    db.collection("chepaihao").where({
      num: car
    }).get({
      success: res => {
        // wx.showToast({
        //   title: '查询成功',
        //   icon:'success',
        //   duration: 2000,
        //    mask:true
        // })
    //     app.globalData.number.push(num)
          this.setData({
          number: res.data[0]//返回的是一个数组，取第一个    
        })
       console.log(car)
      }, 
      // fail:  
        // wx.showToast({
        //   title: '查询失败',
        //   icon:'error',
        //   duration: 1000,
        //   mask:true
        // })
  
        //  console.log("查询失败")
      
    })
    // if (a==null){
    //   wx.showToast({
    //        title: '查询失败',
    //       icon:'error',
    //       duration: 1000,
    //       mask:true
    //     })
    // }
  //  const result= db.where({
  //     num:car
  //   })
  //   .get({
  //     success: console.log,
  //     // fail: console.log("查询失败")
  //     fail:wx.showToast({
  //       title: '查询失败',
  //       icon: 'succes',
  //       duration: 1000,
  //       mask:true
  //   })
  //   })
   

    //查询所有数据
    // db.get({
    //   success(res){
    //     console.log("查询成功", res)
        
    //   },
    //   fail(res){
    //     console.log("查询失败", res)
    //   }
    // })


    
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})